# Twitch M3U Playlist

Repo ini berisi file `.m3u8` untuk memutar channel Twitch di aplikasi IPTV.
Cukup ambil raw link dari file `mytwitch.m3u8` dan gunakan di aplikasi IPTV
(OTT Navigator, IPTV Smarters, atau app Android kamu).

**Link RAW:**  
```
https://raw.githubusercontent.com/gamerepublictv/twitch-m3u/main/mytwitch.m3u8
```

> ⚠️ Catatan: Link Twitch `.m3u8` biasanya hanya berlaku beberapa menit/jam.
> Kamu perlu update file ini secara manual atau menggunakan script auto-refresh
> agar selalu dapat link terbaru.
